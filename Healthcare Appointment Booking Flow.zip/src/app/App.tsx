import { useState, useRef, useEffect, useCallback } from "react";
import {
  Send, MapPin, Star, Calendar, AlertTriangle,
  Activity, ChevronRight, Bot, User, Sparkles,
  ArrowLeft, CheckCircle2, X, Clock
} from "lucide-react";
import { CalendarPicker } from "./components/CalendarPicker";
import { ConfirmationScreen } from "./components/ConfirmationScreen";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  location: string;
  rating: number;
  reviewCount: number;
  nextAvailable: string;
  image: string;
  distance: string;
}

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: Date;
  doctors?: Doctor[];
  tips?: { title: string; body: string }[];
  quickActions?: string[];
  isTyping?: boolean;
  bookingSuccess?: { doctorName: string; date: string; time: string };
}

interface Appointment {
  doctor: Doctor;
  date: Date;
  time: string;
}

// ─── Mock Data ────────────────────────────────────────────────────────────────

const USER_PROFILE = {
  name: "Sarah Mitchell",
  age: 34,
  riskScore: 78,
  riskLevel: "High" as const,
  bmi: 31.2,
  factors: ["Sedentary lifestyle", "High-calorie diet", "Family history", "Irregular sleep"],
  location: "Dallas, TX",
  network: "Baylor Scott & White Health",
};

const DOCTORS: Doctor[] = [
  {
    id: "dr-chen",
    name: "Dr. Emily Chen, MD",
    specialty: "Obesity & Metabolic Medicine",
    location: "Baylor University Medical Center",
    rating: 4.9,
    reviewCount: 234,
    nextAvailable: "Today, 3:30 PM",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&auto=format",
    distance: "1.8 miles",
  },
  {
    id: "dr-patel",
    name: "Dr. Raj Patel, MD",
    specialty: "Internal & Preventive Medicine",
    location: "Baylor Scott & White – Uptown",
    rating: 4.8,
    reviewCount: 187,
    nextAvailable: "Tomorrow, 9:00 AM",
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&auto=format",
    distance: "2.4 miles",
  },
];

// ─── Response Engine ──────────────────────────────────────────────────────────

function buildResponse(input: string): Omit<ChatMessage, "id" | "role" | "timestamp" | "isTyping"> {
  const l = input.toLowerCase();

  if (/\b(hi|hello|hey|start|begin|sup)\b/.test(l)) {
    return {
      text: "Hello, Sarah. I have reviewed your most recent health assessment and risk profile. You are currently in a high-risk category for obesity-related complications — but that is precisely why early action matters most. At this stage, targeted interventions are highly effective. I am here to help you in two ways: I can share evidence-based steps you can start today, or I can connect you with a Baylor specialist near you in Dallas. How would you like to begin?",
      quickActions: ["Weight & nutrition tips", "Find a doctor", "Exercise guidance", "Sleep & recovery"],
    };
  }

  if (/\b(weight|diet|nutrition|food|eat|meal|calori|carb|protein|fast)\b/.test(l)) {
    return {
      text: "Based on your profile and current clinical guidelines, here are three evidence-based dietary adjustments most effective for your risk factors. Because your assessment noted irregular meal timing, aligning your eating window with your waking hours is particularly impactful.",
      tips: [
        {
          title: "Time-restricted eating — 10-hour window",
          body: "Limit food intake to a consistent window such as 8 AM–6 PM. This alone reduces average daily caloric intake by 15–20% without strict counting and improves insulin sensitivity within 2 weeks.",
        },
        {
          title: "Protein-first meals",
          body: "Begin each meal with 25–30g of lean protein (eggs, chicken, legumes). This slows gastric emptying, regulates appetite hormones, and reduces overall meal calories without hunger.",
        },
        {
          title: "Eliminate liquid calories",
          body: "Replacing sweetened beverages with water, black coffee, or unsweetened tea removes an average of 350 excess calories per day — one of the highest-return single changes for your profile.",
        },
      ],
      doctors: [DOCTORS[0]],
      quickActions: ["Exercise tips", "Book Dr. Chen", "Sleep advice", "More nutrition guidance"],
    };
  }

  if (/\b(exercise|workout|activity|move|steps|gym|walk|run)\b/.test(l)) {
    return {
      text: "For your risk profile, structured movement delivers the highest return of any single intervention. The ACSM protocol for high-risk individuals at your BMI focuses on consistency over intensity — especially in the first 8 weeks.",
      tips: [
        {
          title: "Start with daily walking",
          body: "20 minutes of brisk walking (3 mph) five days per week. This alone significantly reduces insulin resistance within 2 weeks and burns 150–200 calories per session.",
        },
        {
          title: "Resistance training twice weekly",
          body: "Bodyweight squats, push-ups, and rows preserve lean muscle mass, which directly improves your resting metabolic rate and is protective against weight regain.",
        },
        {
          title: "Maximize NEAT (non-exercise activity)",
          body: "Taking stairs, standing desks, and walking during calls can add 300–500 extra calories burned daily with zero scheduled workout time — a major advantage for busy schedules.",
        },
      ],
      quickActions: ["Nutrition tips", "Find a doctor", "Sleep advice"],
    };
  }

  if (/\b(book|appointment|doctor|schedule|see|physician|visit|consult|find|near)\b/.test(l)) {
    return {
      text: "I have identified two Baylor Scott & White physicians near your location in Dallas who specialize in preventive and obesity medicine. Both are accepting new patients within your network. Dr. Chen at Baylor University Medical Center is the closest — just 1.8 miles away — with availability as early as this afternoon.",
      doctors: DOCTORS,
      quickActions: ["Book with Dr. Chen", "Book with Dr. Patel", "Get health tips first"],
    };
  }

  if (/\b(sleep|rest|insomnia|tired|fatigue|bedtime|night)\b/.test(l)) {
    return {
      text: "Sleep quality is directly correlated with metabolic health and weight regulation. Research shows sleeping under 6 hours increases ghrelin (the hunger hormone) by 28% and decreases leptin (satiety hormone) by 18% — both of which amplify the risk factors in your profile.",
      tips: [
        {
          title: "Target 7–9 hours with a fixed schedule",
          body: "Set a consistent bedtime and wake time, including weekends. Consistency regulates cortisol, which directly controls where your body stores fat.",
        },
        {
          title: "Screens off 60 minutes before bed",
          body: "Blue light suppresses melatonin production by up to 50%. Switch to reading or dimmed warm lighting in the final hour to accelerate sleep onset.",
        },
        {
          title: "Cool your bedroom to 65–68°F",
          body: "Core body temperature drop is the primary trigger for sleep onset and deeper sleep stages. This single environmental change improves sleep quality for most people within days.",
        },
      ],
      quickActions: ["Nutrition advice", "Exercise tips", "Book a doctor"],
    };
  }

  if (/\b(stress|anxiety|mental|mood|overwhelm|worry|pressure)\b/.test(l)) {
    return {
      text: "Chronic stress elevates cortisol, which promotes abdominal fat accumulation and triggers cravings for high-calorie foods — a direct contributor to your risk profile. The following interventions are supported by strong clinical evidence:",
      tips: [
        {
          title: "Box breathing — 4-4-4-4",
          body: "Inhale 4 seconds, hold 4, exhale 4, hold 4. Just 5 minutes daily reduces cortisol by measurable amounts within one week of consistent practice.",
        },
        {
          title: "Brief outdoor walks",
          body: "10 minutes of natural daylight and movement simultaneously lowers cortisol and increases serotonin — more effective than either alone.",
        },
        {
          title: "Limit news and social media to 30 min/day",
          body: "Digital overload is a primary driver of low-grade chronic stress in your age group and is consistently underestimated as a metabolic risk factor.",
        },
      ],
      doctors: [DOCTORS[1]],
      quickActions: ["Nutrition tips", "Exercise guidance", "Book Dr. Patel"],
    };
  }

  return {
    text: "That is a great question. Based on your health profile and the latest clinical guidelines, I can share personalized guidance on nutrition, exercise, sleep, or stress management — or help you connect with a Baylor specialist near you in Dallas. Which area would you like to explore?",
    quickActions: ["Weight & nutrition tips", "Find a doctor", "Exercise guidance", "Sleep & recovery"],
  };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function formatTime(d: Date) {
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function RiskBadge({ score }: { score: number }) {
  const color = score >= 70 ? "text-accent" : score >= 40 ? "text-yellow-600" : "text-green-600";
  return (
    <div className="flex items-center gap-1.5">
      <AlertTriangle className={`w-3.5 h-3.5 ${color}`} aria-hidden />
      <span className={`text-xs font-semibold uppercase tracking-wider font-mono ${color}`}>
        High Risk
      </span>
    </div>
  );
}

function ProfileSidebar({ onQuickAction }: { onQuickAction: (a: string) => void }) {
  return (
    <aside
      className="hidden lg:flex flex-col w-72 xl:w-80 bg-card border-r border-border shrink-0"
      aria-label="Patient risk profile"
    >
      {/* Header */}
      <div className="px-6 py-5 border-b border-border">
        <div className="flex items-center gap-2 mb-0.5">
          <Activity className="w-4 h-4 text-primary" aria-hidden />
          <span className="text-xs font-semibold uppercase tracking-widest text-muted-foreground font-mono">
            Risk Profile
          </span>
        </div>
        <p className="text-[11px] text-muted-foreground mt-1">{USER_PROFILE.network}</p>
      </div>

      {/* Patient info */}
      <div className="px-6 py-5 border-b border-border">
        <div className="flex items-start gap-3">
          <div className="w-11 h-11 rounded-full bg-secondary flex items-center justify-center shrink-0">
            <User className="w-5 h-5 text-primary" aria-hidden />
          </div>
          <div>
            <p className="font-semibold text-foreground leading-tight">{USER_PROFILE.name}</p>
            <p className="text-sm text-muted-foreground">{USER_PROFILE.age} years · {USER_PROFILE.location}</p>
          </div>
        </div>
      </div>

      {/* Risk score */}
      <div className="px-6 py-5 border-b border-border">
        <RiskBadge score={USER_PROFILE.riskScore} />
        <div className="mt-3 flex items-end gap-2">
          <span
            className="text-5xl font-light text-accent leading-none font-mono"
            aria-label={`Risk score ${USER_PROFILE.riskScore} out of 100`}
          >
            {USER_PROFILE.riskScore}
          </span>
          <span className="text-muted-foreground text-sm mb-1.5">/100</span>
        </div>
        <div className="mt-3 h-1.5 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-accent rounded-full transition-all"
            style={{ width: `${USER_PROFILE.riskScore}%` }}
            role="progressbar"
            aria-valuenow={USER_PROFILE.riskScore}
            aria-valuemin={0}
            aria-valuemax={100}
          />
        </div>
        <div className="mt-3 flex justify-between text-[11px] font-mono text-muted-foreground">
          <span>BMI {USER_PROFILE.bmi}</span>
          <span>Last assessed today</span>
        </div>
      </div>

      {/* Risk factors */}
      <div className="px-6 py-5 border-b border-border">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Contributing Factors</p>
        <ul className="space-y-2">
          {USER_PROFILE.factors.map((f) => (
            <li key={f} className="flex items-center gap-2 text-sm text-foreground">
              <span className="w-1.5 h-1.5 rounded-full bg-accent shrink-0" aria-hidden />
              {f}
            </li>
          ))}
        </ul>
      </div>

      {/* Quick actions */}
      <div className="px-6 py-5 flex-1">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Quick Start</p>
        <div className="space-y-1.5">
          {["Weight & nutrition tips", "Find a doctor", "Exercise guidance", "Sleep & recovery"].map((action) => (
            <button
              key={action}
              onClick={() => onQuickAction(action)}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm text-foreground hover:bg-secondary hover:text-primary transition-colors text-left group"
              aria-label={`Start chat about ${action}`}
            >
              <span>{action}</span>
              <ChevronRight className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors" aria-hidden />
            </button>
          ))}
        </div>
      </div>
    </aside>
  );
}

function TypingIndicator() {
  return (
    <div className="flex items-end gap-3" aria-label="Assistant is typing" aria-live="polite">
      <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0">
        <Bot className="w-4 h-4 text-primary-foreground" aria-hidden />
      </div>
      <div className="bg-card border border-border rounded-2xl rounded-bl-sm px-4 py-3">
        <div className="flex items-center gap-1.5" aria-hidden>
          <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:0ms]" />
          <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:150ms]" />
          <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:300ms]" />
        </div>
      </div>
    </div>
  );
}

function DoctorCard({ doctor, onBook }: { doctor: Doctor; onBook: (d: Doctor) => void }) {
  return (
    <div className="bg-background border border-border rounded-xl p-4 flex gap-3 hover:border-primary/30 transition-colors">
      <img
        src={doctor.image}
        alt={doctor.name}
        className="w-12 h-12 rounded-full object-cover shrink-0 bg-muted"
      />
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-sm text-foreground truncate">{doctor.name}</p>
        <p className="text-xs text-muted-foreground">{doctor.specialty}</p>
        <div className="flex items-center gap-3 mt-1.5">
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" aria-hidden />
            {doctor.distance}
          </span>
          <span className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" aria-hidden />
            {doctor.rating} ({doctor.reviewCount})
          </span>
        </div>
        <div className="flex items-center justify-between mt-2.5">
          <span className="flex items-center gap-1 text-xs text-primary font-medium">
            <Clock className="w-3 h-3" aria-hidden />
            {doctor.nextAvailable}
          </span>
          <button
            onClick={() => onBook(doctor)}
            className="flex items-center gap-1 text-xs font-semibold bg-primary text-primary-foreground px-3 py-1.5 rounded-lg hover:bg-primary/90 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={`Book appointment with ${doctor.name}`}
          >
            <Calendar className="w-3 h-3" aria-hidden />
            Book
          </button>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({
  msg,
  onBook,
  onQuickAction,
}: {
  msg: ChatMessage;
  onBook: (d: Doctor) => void;
  onQuickAction: (a: string) => void;
}) {
  const isUser = msg.role === "user";

  if (msg.isTyping) return <TypingIndicator />;

  return (
    <div
      className={`flex items-end gap-3 ${isUser ? "flex-row-reverse" : ""}`}
      role="listitem"
    >
      {/* Avatar */}
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
          isUser ? "bg-secondary" : "bg-primary"
        }`}
        aria-hidden
      >
        {isUser ? (
          <User className="w-4 h-4 text-primary" />
        ) : (
          <Bot className="w-4 h-4 text-primary-foreground" />
        )}
      </div>

      {/* Content */}
      <div className={`flex flex-col gap-2 max-w-[80%] ${isUser ? "items-end" : "items-start"}`}>
        {/* Main bubble */}
        <div
          className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
            isUser
              ? "bg-primary text-primary-foreground rounded-br-sm"
              : "bg-card border border-border text-foreground rounded-bl-sm [font-family:'Literata',serif]"
          }`}
        >
          {msg.text}
        </div>

        {/* Tips */}
        {msg.tips && msg.tips.length > 0 && (
          <div className="w-full space-y-2 max-w-lg">
            {msg.tips.map((tip, i) => (
              <div key={i} className="bg-card border border-border rounded-xl p-3.5">
                <div className="flex gap-2.5">
                  <span
                    className="w-5 h-5 rounded-full bg-primary/10 text-primary text-xs font-mono font-bold flex items-center justify-center shrink-0 mt-0.5"
                    aria-hidden
                  >
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-foreground leading-snug">{tip.title}</p>
                    <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed [font-family:'Literata',serif]">{tip.body}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Doctor cards */}
        {msg.doctors && msg.doctors.length > 0 && (
          <div className="w-full max-w-sm space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">
              Nearby Baylor Physicians
            </p>
            {msg.doctors.map((d) => (
              <DoctorCard key={d.id} doctor={d} onBook={onBook} />
            ))}
          </div>
        )}

        {/* Booking success */}
        {msg.bookingSuccess && (
          <div className="bg-green-50 border border-green-200 rounded-xl px-4 py-3 flex items-start gap-3 max-w-sm">
            <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" aria-hidden />
            <div>
              <p className="text-sm font-semibold text-green-800">Appointment confirmed</p>
              <p className="text-xs text-green-700 mt-0.5">
                {msg.bookingSuccess.doctorName} · {msg.bookingSuccess.date} · {msg.bookingSuccess.time}
              </p>
            </div>
          </div>
        )}

        {/* Quick actions */}
        {msg.quickActions && msg.quickActions.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-1">
            {msg.quickActions.map((a) => (
              <button
                key={a}
                onClick={() => onQuickAction(a)}
                className="text-xs px-3 py-1.5 rounded-full border border-border bg-card text-foreground hover:bg-secondary hover:border-primary/30 hover:text-primary transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={`Ask about ${a}`}
              >
                {a}
              </button>
            ))}
          </div>
        )}

        {/* Timestamp */}
        <time
          dateTime={msg.timestamp.toISOString()}
          className="text-[10px] text-muted-foreground font-mono px-1"
          aria-label={`Sent at ${formatTime(msg.timestamp)}`}
        >
          {formatTime(msg.timestamp)}
        </time>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

type AppMode = "chat" | "calendar" | "confirmation";

export default function App() {
  const [mode, setMode] = useState<AppMode>("chat");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: uid(),
      role: "assistant",
      text: `Welcome, ${USER_PROFILE.name}. I'm your Baylor Health AI assistant. Based on your recently completed health survey, your obesity risk score is ${USER_PROFILE.riskScore}/100 — placing you in the high-risk category. The encouraging news: this is exactly when early intervention is most effective. I can provide personalized, evidence-based guidance right now, and connect you with a Baylor physician nearby if you'd like a professional consultation. How can I help you today?`,
      timestamp: new Date(),
      quickActions: ["Weight & nutrition tips", "Find a doctor", "Exercise guidance", "Sleep & recovery"],
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [appointment, setAppointment] = useState<Appointment | null>(null);
  const [mobileProfileOpen, setMobileProfileOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = useCallback(
    (text: string) => {
      if (!text.trim() || isTyping) return;

      const userMsg: ChatMessage = {
        id: uid(),
        role: "user",
        text: text.trim(),
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, userMsg]);
      setInputValue("");
      setIsTyping(true);

      const typingId = uid();
      setMessages((prev) => [
        ...prev,
        { id: typingId, role: "assistant", text: "", timestamp: new Date(), isTyping: true },
      ]);

      const delay = 1200 + Math.random() * 800;

      setTimeout(() => {
        const response = buildResponse(text);
        setIsTyping(false);
        setMessages((prev) =>
          prev.map((m) =>
            m.id === typingId
              ? { ...m, ...response, isTyping: false, timestamp: new Date() }
              : m
          )
        );
      }, delay);
    },
    [isTyping]
  );

  const handleQuickAction = useCallback(
    (action: string) => {
      // Special: "Book with Dr. X" actions
      const bookMatch = action.match(/^Book (?:with )?(Dr\. .+)/i);
      if (bookMatch) {
        const found = DOCTORS.find((d) =>
          d.name.toLowerCase().includes(bookMatch[1].toLowerCase())
        );
        if (found) {
          setSelectedDoctor(found);
          setMode("calendar");
          return;
        }
      }
      sendMessage(action);
      setTimeout(() => inputRef.current?.focus(), 50);
    },
    [sendMessage]
  );

  const handleBookDoctor = useCallback((doctor: Doctor) => {
    setSelectedDoctor(doctor);
    setMode("calendar");
  }, []);

  const handleSelectDateTime = useCallback(
    (date: Date, time: string) => {
      if (selectedDoctor) {
        setAppointment({ doctor: selectedDoctor, date, time });
        setMode("confirmation");
      }
    },
    [selectedDoctor]
  );

  const handleConfirm = useCallback(() => {
    if (appointment) {
      const successMsg: ChatMessage = {
        id: uid(),
        role: "assistant",
        text: `Your appointment has been confirmed. You are all set to see ${appointment.doctor.name} at ${appointment.doctor.location}. Please arrive 10 minutes early to complete intake paperwork. In the meantime, I recommend starting with the dietary adjustments we discussed — even small changes before your visit will help your physician tailor recommendations more precisely.`,
        timestamp: new Date(),
        bookingSuccess: {
          doctorName: appointment.doctor.name,
          date: appointment.date.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }),
          time: appointment.time,
        },
        quickActions: ["Weight & nutrition tips", "Exercise guidance", "Sleep & recovery"],
      };
      setMessages((prev) => [...prev, successMsg]);
    }
    setMode("chat");
    setSelectedDoctor(null);
    setAppointment(null);
  }, [appointment]);

  // ── Booking screens ──

  if (mode === "calendar" && selectedDoctor) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-2xl mx-auto py-8 px-4">
          <button
            onClick={() => setMode("chat")}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 group"
            aria-label="Return to health assistant chat"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" aria-hidden />
            Back to Health Assistant
          </button>
          <CalendarPicker
            doctorName={selectedDoctor.name}
            onSelectDateTime={handleSelectDateTime}
            onBack={() => setMode("chat")}
          />
        </div>
      </div>
    );
  }

  if (mode === "confirmation" && appointment) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-2xl mx-auto py-8 px-4">
          <button
            onClick={() => setMode("calendar")}
            className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6 group"
            aria-label="Return to date selection"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" aria-hidden />
            Change date or time
          </button>
          <ConfirmationScreen
            doctorName={appointment.doctor.name}
            doctorSpecialty={appointment.doctor.specialty}
            doctorLocation={appointment.doctor.location}
            appointmentDate={appointment.date}
            appointmentTime={appointment.time}
            onBack={() => setMode("calendar")}
            onConfirm={handleConfirm}
          />
        </div>
      </div>
    );
  }

  // ── Chat UI ──

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden">
      {/* ── Header ── */}
      <header className="flex items-center justify-between px-4 sm:px-6 py-3.5 bg-card border-b border-border shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center" aria-hidden>
            <Sparkles className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-foreground leading-tight">Health Assistant</h1>
            <p className="text-[11px] text-muted-foreground leading-none mt-0.5">
              Baylor Scott &amp; White Health
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500" aria-hidden />
            <span className="text-xs text-muted-foreground">Online</span>
          </div>
          {/* Mobile profile toggle */}
          <button
            onClick={() => setMobileProfileOpen((v) => !v)}
            className="lg:hidden flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2.5 py-1.5 rounded-lg border border-border"
            aria-expanded={mobileProfileOpen}
            aria-label="Toggle risk profile"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-accent" aria-hidden />
            Risk: {USER_PROFILE.riskScore}
            {mobileProfileOpen ? <X className="w-3 h-3 ml-0.5" aria-hidden /> : null}
          </button>
        </div>
      </header>

      {/* ── Mobile profile banner ── */}
      {mobileProfileOpen && (
        <div className="lg:hidden bg-card border-b border-border px-4 py-3 shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center">
                <User className="w-4 h-4 text-primary" aria-hidden />
              </div>
              <div>
                <p className="text-sm font-semibold">{USER_PROFILE.name}, {USER_PROFILE.age}</p>
                <p className="text-xs text-muted-foreground">{USER_PROFILE.location}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-light text-accent font-mono leading-none">{USER_PROFILE.riskScore}</p>
              <p className="text-[10px] text-muted-foreground font-mono">/ 100 HIGH</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2.5">
            {USER_PROFILE.factors.map((f) => (
              <span key={f} className="text-[10px] px-2 py-0.5 rounded-full bg-accent/10 text-accent border border-accent/20">
                {f}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ── Body ── */}
      <div className="flex flex-1 overflow-hidden">
        <ProfileSidebar onQuickAction={handleQuickAction} />

        {/* ── Chat panel ── */}
        <main className="flex flex-col flex-1 overflow-hidden" aria-label="Health assistant conversation">
          {/* Messages */}
          <div
            className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-6 scroll-smooth"
            role="list"
            aria-label="Conversation messages"
            aria-live="polite"
            aria-atomic="false"
          >
            {messages.map((msg) => (
              <MessageBubble
                key={msg.id}
                msg={msg}
                onBook={handleBookDoctor}
                onQuickAction={handleQuickAction}
              />
            ))}
            <div ref={messagesEndRef} aria-hidden />
          </div>

          {/* ── Input area ── */}
          <div className="shrink-0 px-4 sm:px-6 py-4 bg-card border-t border-border">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                sendMessage(inputValue);
              }}
              className="flex items-center gap-2.5"
              aria-label="Send a message"
            >
              <label htmlFor="chat-input" className="sr-only">
                Type your health question
              </label>
              <input
                id="chat-input"
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Ask about nutrition, exercise, finding a doctor…"
                disabled={isTyping}
                className="flex-1 bg-background border border-border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent disabled:opacity-50 transition-colors"
                autoComplete="off"
                aria-label="Health question input"
              />
              <button
                type="submit"
                disabled={!inputValue.trim() || isTyping}
                className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" aria-hidden />
              </button>
            </form>
            <p className="text-[10px] text-muted-foreground text-center mt-2.5 font-mono">
              AI responses are for informational purposes only · Not a substitute for professional medical advice
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}
