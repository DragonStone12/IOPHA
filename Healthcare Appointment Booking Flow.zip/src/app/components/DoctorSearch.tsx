import { useState } from 'react';
import { Search, MapPin, Star, Clock } from 'lucide-react';

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  location: string;
  rating: number;
  reviewCount: number;
  nextAvailable: string;
  image: string;
}

interface DoctorSearchProps {
  onSelectDoctor: (doctor: Doctor) => void;
}

const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    specialty: 'Cardiologist',
    location: 'Downtown Medical Center',
    rating: 4.8,
    reviewCount: 124,
    nextAvailable: 'Tomorrow',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop'
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialty: 'Dermatologist',
    location: 'Riverside Clinic',
    rating: 4.9,
    reviewCount: 203,
    nextAvailable: 'Today',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop'
  },
  {
    id: '3',
    name: 'Dr. Emily Rodriguez',
    specialty: 'Pediatrician',
    location: 'Family Health Associates',
    rating: 4.7,
    reviewCount: 156,
    nextAvailable: 'In 3 days',
    image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=400&h=400&fit=crop'
  },
  {
    id: '4',
    name: 'Dr. James Anderson',
    specialty: 'Orthopedist',
    location: 'Sports Medicine Center',
    rating: 4.6,
    reviewCount: 98,
    nextAvailable: 'Tomorrow',
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&h=400&fit=crop'
  },
  {
    id: '5',
    name: 'Dr. Lisa Patel',
    specialty: 'General Practitioner',
    location: 'Community Health Clinic',
    rating: 4.9,
    reviewCount: 287,
    nextAvailable: 'Today',
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop'
  }
];

const specialties = ['All Specialties', 'Cardiologist', 'Dermatologist', 'Pediatrician', 'Orthopedist', 'General Practitioner'];

export function DoctorSearch({ onSelectDoctor }: DoctorSearchProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All Specialties');
  const [filteredDoctors, setFilteredDoctors] = useState(mockDoctors);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    filterDoctors(query, selectedSpecialty);
  };

  const handleSpecialtyChange = (specialty: string) => {
    setSelectedSpecialty(specialty);
    filterDoctors(searchQuery, specialty);
  };

  const filterDoctors = (query: string, specialty: string) => {
    let filtered = mockDoctors;

    if (specialty !== 'All Specialties') {
      filtered = filtered.filter(doc => doc.specialty === specialty);
    }

    if (query) {
      filtered = filtered.filter(doc =>
        doc.name.toLowerCase().includes(query.toLowerCase()) ||
        doc.specialty.toLowerCase().includes(query.toLowerCase()) ||
        doc.location.toLowerCase().includes(query.toLowerCase())
      );
    }

    setFilteredDoctors(filtered);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="mb-2">Find Your Doctor</h1>
        <p className="text-gray-600">Search for healthcare providers by name, specialty, or location</p>
      </div>

      <div className="space-y-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Search by name, specialty, or location..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            aria-label="Search for doctors"
          />
        </div>

        <div className="flex gap-2 flex-wrap">
          {specialties.map((specialty) => (
            <button
              key={specialty}
              onClick={() => handleSpecialtyChange(specialty)}
              className={`px-4 py-2 rounded-full transition-colors ${
                selectedSpecialty === specialty
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              aria-pressed={selectedSpecialty === specialty}
            >
              {specialty}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {filteredDoctors.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            No doctors found matching your criteria
          </div>
        ) : (
          filteredDoctors.map((doctor) => (
            <div
              key={doctor.id}
              className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => onSelectDoctor(doctor)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onSelectDoctor(doctor);
                }
              }}
              aria-label={`Book appointment with ${doctor.name}`}
            >
              <div className="flex gap-4">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-20 h-20 rounded-full object-cover flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div>
                      <h3 className="mb-1">{doctor.name}</h3>
                      <p className="text-gray-600">{doctor.specialty}</p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <Star className="text-yellow-500 fill-yellow-500" size={16} />
                      <span className="font-semibold">{doctor.rating}</span>
                      <span className="text-gray-500 text-sm">({doctor.reviewCount})</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <MapPin size={16} />
                      <span>{doctor.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={16} />
                      <span className="text-green-600 font-medium">Next available: {doctor.nextAvailable}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
