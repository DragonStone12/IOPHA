import { useState } from 'react';
import { format } from 'date-fns';
import { CheckCircle, Calendar, Clock, MapPin, User, Mail, Phone, ChevronLeft } from 'lucide-react';

interface ConfirmationScreenProps {
  doctorName: string;
  doctorSpecialty: string;
  doctorLocation: string;
  appointmentDate: Date;
  appointmentTime: string;
  onBack: () => void;
  onConfirm: () => void;
}

export function ConfirmationScreen({
  doctorName,
  doctorSpecialty,
  doctorLocation,
  appointmentDate,
  appointmentTime,
  onBack,
  onConfirm
}: ConfirmationScreenProps) {
  const [patientInfo, setPatientInfo] = useState({
    name: '',
    email: '',
    phone: '',
    reason: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isConfirmed, setIsConfirmed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      setIsSubmitting(false);
      setIsConfirmed(true);
      setTimeout(() => {
        onConfirm();
      }, 3000);
    }, 1500);
  };

  const isFormValid = patientInfo.name && patientInfo.email && patientInfo.phone;

  if (isConfirmed) {
    return (
      <div className="w-full max-w-2xl mx-auto p-6">
        <div className="bg-white border border-gray-200 rounded-lg p-12 text-center">
          <CheckCircle className="mx-auto mb-6 text-green-600" size={64} />
          <h1 className="mb-4">Appointment Confirmed!</h1>
          <p className="text-gray-600 text-lg mb-8">
            You will receive a confirmation email shortly with all the details.
          </p>
          <div className="bg-gray-50 rounded-lg p-6 text-left">
            <h2 className="mb-4">Appointment Summary</h2>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <User className="text-gray-400 mt-1 flex-shrink-0" size={20} />
                <div>
                  <p className="text-sm text-gray-600">Doctor</p>
                  <p className="font-medium">{doctorName}</p>
                  <p className="text-sm text-gray-600">{doctorSpecialty}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Calendar className="text-gray-400 mt-1 flex-shrink-0" size={20} />
                <div>
                  <p className="text-sm text-gray-600">Date & Time</p>
                  <p className="font-medium">
                    {format(appointmentDate, 'EEEE, MMMM d, yyyy')} at {appointmentTime}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="text-gray-400 mt-1 flex-shrink-0" size={20} />
                <div>
                  <p className="text-sm text-gray-600">Location</p>
                  <p className="font-medium">{doctorLocation}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto p-6">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        aria-label="Go back to calendar"
      >
        <ChevronLeft size={20} />
        <span>Back to calendar</span>
      </button>

      <div className="mb-8">
        <h1 className="mb-2">Confirm Your Appointment</h1>
        <p className="text-gray-600">Please review your appointment details and provide your information</p>
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h2 className="mb-6">Patient Information</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  value={patientInfo.name}
                  onChange={(e) => setPatientInfo({ ...patientInfo, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  value={patientInfo.email}
                  onChange={(e) => setPatientInfo({ ...patientInfo, email: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="john.doe@example.com"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  id="phone"
                  required
                  value={patientInfo.phone}
                  onChange={(e) => setPatientInfo({ ...patientInfo, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="(555) 123-4567"
                />
              </div>

              <div>
                <label htmlFor="reason" className="block text-sm font-medium text-gray-700 mb-1">
                  Reason for Visit (Optional)
                </label>
                <textarea
                  id="reason"
                  rows={4}
                  value={patientInfo.reason}
                  onChange={(e) => setPatientInfo({ ...patientInfo, reason: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  placeholder="Brief description of your symptoms or reason for appointment..."
                />
              </div>

              <button
                type="submit"
                disabled={!isFormValid || isSubmitting}
                className={`w-full px-6 py-3 rounded-lg font-medium transition-colors ${
                  isFormValid && !isSubmitting
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
                aria-label="Confirm and book appointment"
              >
                {isSubmitting ? 'Confirming...' : 'Confirm Appointment'}
              </button>
            </form>
          </div>
        </div>

        <div className="lg:col-span-2">
          <div className="bg-white border border-gray-200 rounded-lg p-6 sticky top-6">
            <h2 className="mb-6">Appointment Details</h2>
            <div className="space-y-4">
              <div>
                <div className="flex items-start gap-3">
                  <User className="text-blue-600 mt-1 flex-shrink-0" size={20} />
                  <div className="min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Healthcare Provider</p>
                    <p className="font-medium">{doctorName}</p>
                    <p className="text-sm text-gray-600">{doctorSpecialty}</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-start gap-3">
                  <Calendar className="text-blue-600 mt-1 flex-shrink-0" size={20} />
                  <div className="min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Date</p>
                    <p className="font-medium">{format(appointmentDate, 'EEEE, MMMM d, yyyy')}</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-start gap-3">
                  <Clock className="text-blue-600 mt-1 flex-shrink-0" size={20} />
                  <div className="min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Time</p>
                    <p className="font-medium">{appointmentTime}</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <div className="flex items-start gap-3">
                  <MapPin className="text-blue-600 mt-1 flex-shrink-0" size={20} />
                  <div className="min-w-0">
                    <p className="text-sm text-gray-600 mb-1">Location</p>
                    <p className="font-medium">{doctorLocation}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-700">
                <strong>Note:</strong> Please arrive 15 minutes early to complete any necessary paperwork.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
