import { useState } from 'react';
import { DayPicker } from 'react-day-picker';
import { format, addDays, isSameDay } from 'date-fns';
import { ChevronLeft, Clock } from 'lucide-react';
import 'react-day-picker/dist/style.css';

interface CalendarPickerProps {
  doctorName: string;
  onSelectDateTime: (date: Date, time: string) => void;
  onBack: () => void;
}

const availableTimeSlots = [
  '09:00 AM',
  '09:30 AM',
  '10:00 AM',
  '10:30 AM',
  '11:00 AM',
  '11:30 AM',
  '01:00 PM',
  '01:30 PM',
  '02:00 PM',
  '02:30 PM',
  '03:00 PM',
  '03:30 PM',
  '04:00 PM',
  '04:30 PM'
];

export function CalendarPicker({ doctorName, onSelectDateTime, onBack }: CalendarPickerProps) {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>();

  const today = new Date();
  const disabledDays = { before: today };

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    setSelectedTime(undefined);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
  };

  const handleConfirm = () => {
    if (selectedDate && selectedTime) {
      onSelectDateTime(selectedDate, selectedTime);
    }
  };

  const getAvailableSlots = () => {
    if (!selectedDate) return [];

    if (isSameDay(selectedDate, today)) {
      const currentHour = today.getHours();
      return availableTimeSlots.filter(slot => {
        const [time, period] = slot.split(' ');
        const [hours] = time.split(':').map(Number);
        const hour24 = period === 'PM' && hours !== 12 ? hours + 12 : hours === 12 && period === 'AM' ? 0 : hours;
        return hour24 > currentHour;
      });
    }

    return availableTimeSlots;
  };

  const availableSlots = getAvailableSlots();

  return (
    <div className="w-full max-w-4xl mx-auto p-6">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        aria-label="Go back to doctor search"
      >
        <ChevronLeft size={20} />
        <span>Back to search</span>
      </button>

      <div className="mb-8">
        <h1 className="mb-2">Select Appointment Time</h1>
        <p className="text-gray-600">Booking with {doctorName}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h2 className="mb-4">Choose a Date</h2>
          <DayPicker
            mode="single"
            selected={selectedDate}
            onSelect={handleDateSelect}
            disabled={disabledDays}
            fromDate={today}
            toDate={addDays(today, 60)}
            className="mx-auto"
            modifiersClassNames={{
              selected: 'bg-blue-600 text-white hover:bg-blue-700',
              today: 'font-bold text-blue-600'
            }}
          />
        </div>

        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h2 className="mb-4">Choose a Time</h2>
          {!selectedDate ? (
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <Clock className="mx-auto mb-2" size={32} />
                <p>Please select a date first</p>
              </div>
            </div>
          ) : availableSlots.length === 0 ? (
            <div className="flex items-center justify-center h-64 text-gray-500">
              <div className="text-center">
                <p>No available time slots for this date</p>
                <p className="text-sm mt-2">Please select another date</p>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2 max-h-96 overflow-y-auto">
              {availableSlots.map((time) => (
                <button
                  key={time}
                  onClick={() => handleTimeSelect(time)}
                  className={`px-4 py-3 rounded-lg border transition-all ${
                    selectedTime === time
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white border-gray-300 hover:border-blue-600 hover:bg-blue-50'
                  }`}
                  aria-pressed={selectedTime === time}
                >
                  {time}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {selectedDate && selectedTime && (
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p className="text-gray-600 text-sm mb-1">Selected appointment:</p>
              <p className="font-semibold text-lg">
                {format(selectedDate, 'EEEE, MMMM d, yyyy')} at {selectedTime}
              </p>
            </div>
            <button
              onClick={handleConfirm}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
              aria-label="Confirm appointment selection"
            >
              Continue to Confirmation
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
